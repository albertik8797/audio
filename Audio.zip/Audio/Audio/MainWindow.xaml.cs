﻿using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Audio
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
/*        public static List<string> src = new List<string>();*/
        private Random random = new Random();
        private static bool man = true;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void media_MediaOpened(object sender, RoutedEventArgs e)
        {
            polsunokAudio.Maximum = media.NaturalDuration.TimeSpan.Ticks;
            muzEnd.Text = new TimeSpan(Convert.ToInt64(polsunokAudio.Maximum)).ToString(@"mm\:ss");
        }

        private void filePicker_Click(object sender, RoutedEventArgs e)
        {
            CommonOpenFileDialog dialog = new CommonOpenFileDialog { IsFolderPicker = true };
            var res = dialog.ShowDialog();
            if (res == CommonFileDialogResult.Ok)
            {
                FilePickSort(dialog.FileName.ToString());
            }
        }

        private void Pov_Click(object sender, RoutedEventArgs e)
        {
            if (strim.povtor)
            {
                strim.povtor = false;
            }
            else if (strim.povtor == false)
            {
                strim.povtor = true;
            }
        }

        private void Sled_Click(object sender, RoutedEventArgs e)
        {
            nextSong(strim.numberOfSong);
        }
        private void nextSong(int index)
        {
            media.Source = new Uri(strim.audioSource[index + 1]);
            media.Play();
            media.Volume = 1;
            strim.numberOfSong++;
            man = false;
        }

        private void PlayOf_Click(object sender, RoutedEventArgs e)
        {
            if (man == false)
            {
                var stoppedAudioPosition = media.Position.Ticks;
                playPause(strim.numberOfSong, stoppedAudioPosition);
            }
            else if (man == true)
            {
                playPause();
            }
        }
        private void playPause(int index = 0, long pol = 0)
        {
            if (man == false)
            {
                media.Source = new Uri(strim.audioSource[index]);
                media.Play();
                if (pol != 0)
                {
                    media.Position = new TimeSpan(pol);
                }
                media.Volume = 1;
                man = true;
            }
            else if (man == true)
            {
                media.Pause();
                man = false;
            }
        }

        private void Pred_Click(object sender, RoutedEventArgs e)
        {
            backSong(strim.numberOfSong);
        }
        private void backSong(int index)
        {
            media.Source = new Uri(strim.audioSource[index - 1]);
            media.Play();
            media.Volume = 1;
            strim.numberOfSong--;
            man = false;
        }

        private void Perem_Click(object sender, RoutedEventArgs e)
        {
            if (strim.peremeshkaIsGoing)
            {
                strim.peremeshkaIsGoing = false;
            }
            else if (strim.peremeshkaIsGoing != true)
            {
                int col = random.Next(0, strim.audioSource.Count);
                man = true;
                media.Source = new Uri(strim.audioSource[strim.numberOfSong]);
                media.Play();
                media.Volume = 1;
                strim.peremeshkaIsGoing = true;
            }
        }

        private void polsunokAudio_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            media.Position = new TimeSpan(Convert.ToInt64(polsunokAudio.Value));
        }

        private void playlist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            strim.numberOfSong = playlist.SelectedIndex;
            playPause(strim.numberOfSong);
        }
        private void FilePickSort(string dialog)
        {
            DirectoryInfo file = new DirectoryInfo(dialog);
            List<string> elementsOfList = new List<string>();
            FileInfo[] Data = file.GetFiles("*.*");
            foreach (var item in Data)
            {
                if (item.Name.EndsWith(".m4a") || item.Name.EndsWith(".vav") || item.Name.EndsWith(".mp3") || item.Name.EndsWith(".flac"))
                {
                    elementsOfList.Add(item.Name);
                    strim.audioSource.Add(item.FullName);
                }
            }
            playlist.ItemsSource = elementsOfList;
            firstSong();
            Thread thread = new Thread(_ => { strim.sliderPainter(this); });
            thread.Start();
        }
        private void firstSong()
        {
            media.Source = new Uri(strim.audioSource[0]);
            media.Play();
            media.Volume = 1;
            strim.numberOfSong = 0;
            man = true;
        }
    }
}
