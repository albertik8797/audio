﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Audio
{
    internal class strim
    {
        public static bool povtor = false;
        public static bool peremeshkaIsGoing = false;
        public static List<string> audioSource = new List<string>();
        public static int numberOfSong = 0;

        public static void sliderPainter(MainWindow window)
        {
            while (true)
            {

                window.Dispatcher.Invoke(() =>
                {
                    window.polsunokAudio.Value = Convert.ToDouble(window.media.Position.Ticks);
                    window.muzStart.Text = new TimeSpan(Convert.ToInt64(window.polsunokAudio.Value)).ToString(@"mm\:ss");
                    if (Convert.ToDouble(window.media.Position.Ticks) == window.polsunokAudio.Maximum)
                    {
                        window.media.Source = new Uri(audioSource[numberOfSong + 1]);
                        window.media.Play();
                        window.media.Volume = 1;
                        numberOfSong++;
                    }
                    else if (Convert.ToDouble(window.media.Position.Ticks) == window.polsunokAudio.Maximum && povtor == true)
                    {
                        window.media.Source = new Uri(audioSource[numberOfSong]);
                        window.media.Play();
                        window.media.Volume = 1;
                    }
                    else if (Convert.ToDouble(window.media.Position.Ticks) == window.polsunokAudio.Maximum && peremeshkaIsGoing == true)
                    {
                        Random random = new Random();
                        int randomSong = random.Next(0, audioSource.Count);
                        window.media.Source = new Uri(audioSource[numberOfSong]);
                        window.media.Play();
                        window.media.Volume = 1;
                    }
                });
                Thread.Sleep(100);
            }
        }
    }
}
